package project1;

import java.util.Scanner;

public class book {
	protected void msg() {
		//public static void main(String[] args) {
			// TODO Auto-generated method stub
		System.out.println("enter any book name you want from below list:\n"+"1.macbeth\n"+"2.hamlet\n"+"3.cuckold\n"+"4.shame\n"+"5.untouchable\n"+"6.beloved\n"+"7.speak\n"+"8.nirmala");
		Scanner du=new Scanner(System.in);
	String input=du.next();
	switch(input){
		case "macbeth":
			System.out.println(" macbeth book is in stock\n"+"macbeth by willam shakespeare\n"+"price=250");
			System.out.println("enter how many book you want:");
			Scanner ll=new Scanner(System.in);
		    int get4=ll.nextInt();
		    int tot1=250*get4;
			System.out.println("total book price: "+tot1);
		break;
		case "hamlet":
			System.out.println("hamlet book is in stock\n"+"hamlet by willam shespeare\n"+"price=500");
			System.out.println("enter how many book you want:");
			Scanner mm=new Scanner(System.in);
		    int get5=mm.nextInt();
		    int tot2=500*get5;
			System.out.println("total book price: "+tot2);		
		break;
		case "cuckold":
			System.out.println("cuckold book is in stock\n"+"cockold by kiran nagarkar\n"+"price=450");
			System.out.println("enter how many book you want:");
			Scanner oo=new Scanner(System.in);
		    int get6=oo.nextInt();
		    int tot3=450*get6;
			System.out.println("total book price: "+tot3);
		break;
		case "beloved":
			System.out.println("beloved book is in stock\n"+"beloved by Toni\n"+"price=300");
			System.out.println("enter how many book you want:");
			Scanner pp=new Scanner(System.in);
		    int get7=pp.nextInt();
		    int tot4=300*get7;
			System.out.println("total book price:"+tot4);
			break;
		case "shame":
			System.out.println("shame book is in stock\n"+"shame by salman rushdie\n"+"price=670");
			System.out.println("enter how many book you want:");
			Scanner rr=new Scanner(System.in);
		    int get8=rr.nextInt();
		    int tot5=670*get8;
			System.out.println("total book price: "+tot5);
		break;
		case "untouchable":
			System.out.println("untouchable is in stock\n"+"untouchable by mulk raj anand\n"+"price=770");
			System.out.println("enter how many book you want:");
			Scanner zz=new Scanner(System.in);
			int get9=zz.nextInt();
			int tot6=770*get9;
			System.out.println("total book price: "+tot6);
			break;
		case "speak":
			System.out.println("speak is in stock\n"+"speak by janell cannon\n"+"price=350");
			System.out.println("enter how many book you want:");
			Scanner vv=new Scanner(System.in);
			int get10=vv.nextInt();
			int tot7=350*get10;
			System.out.println("total book price: "+tot7);
			break;
		case "nirmala":
			System.out.println("nirmala book is in stock\n"+"nirmala by munshi prem\n"+"price=900");
			System.out.println("enter how many book you want:");
			Scanner uu=new Scanner(System.in);
			int get11=uu.nextInt();
			int tot8=900*get11;
			System.out.println("total book price: "+tot8);
			break;
			default:
			System.out.println("this book not found sorry");
	        System.exit(0);
	}
	Scanner pu=new Scanner(System.in);
	System.out.println("****Select payment method you want****");
	System.out.println("1.press ONE for cash on delivery");
	System.out.println("2.press TWO for online payment");
	int num=pu.nextInt();
		if(num==1)
		   {
			System.out.println("->you pressed cash on delivery\n"+"->your order is confirmed\n"+"****we provide free delivery****");
	        System.exit(0);
		   }
		else 
		    {
			 System.out.println("->You pressed online payment\n"+"->Pls select any one to proceed\n");
		     System.out.println("press 1 for Gpay\n"+"press 2 for Netbanking\n"+"press 3 for Phone-pay");
		     Scanner cc=new Scanner(System.in);
		     int get=cc.nextInt();
		     {
			 if(get==1)
			 {
				System.out.println("YOU select gpay mehod through gpay application you can pay\n"+"***we provide free delivery****");

			 }
			else if(get==2) 
			{
				System.out.println("YOU select netbanking method through netbanking application you can pay\n"+"****we provide free delivery****");

			}
			else  
			{
				System.out.println(" YOU select phonepay method through phone-pay application you can pay\n"+"****we provide free delivery****");

		    }
		}
		}
	}
}
/*case "untouchable":
System.out.println("untouchable is in stock\n"+"untouchable by mulk raj anand\n"+"price=770");
System.out.println("enter how many book you want:");
Scanner zz=new Scanner(System.in);
int get8=zz.nextInt();
int tot5=770*get8;
System.out.println("total book price"+tot5);*/
/*case "beloved":
System.out.println("beloved is in stock\n"+"beloved by Toni Morrison\n"+"price=200");
System.out.println("enter how many book you want:");
Scanner rr=new Scanner(System.in);
int get9=rr.nextInt();
int tot6=200*get9;
System.out.println("total book price"+tot6);
case "speak":
System.out.println("speak is in stock\n"+"speak by janell cannon\n"+"price=350");
System.out.println("enter how many book you want:");
Scanner vv=new Scanner(System.in);
int get10=vv.nextInt();
int tot7=350*get10;
System.out.println("total book price"+tot7);*/
