package project1;
import java.util.Scanner;
public class Main extends book {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name,email,address,state;
		int i;
		double pin,no;
System.out.println("!!!welcome to online book store!!!");
System.out.println("pls do register to buy book");
Scanner ss=new Scanner(System.in);
System.out.println("*****If you are already register pls press 1***** ");
System.out.println("****If u are an new user press 2**** ");
i=ss.nextInt();
if(i==1) {	
	System.out.println("Enter your emailAddress: ");
	name=ss.next();
	System.out.println("Enter your phno: ");
	no=ss.nextDouble();
	book obj=new book();
	obj.msg();
}else {
Scanner sc=new Scanner(System.in);
System.out.println("Enter your name: ");
name=sc.next();
System.out.println("Enter your ph.no: ");
no=sc.nextDouble();
System.out.println("Enter your email id: ");
email=sc.next();
System.out.println("Enter your Address and State details to deliver book: ");
address=sc.next();
System.out.println("Enter PINcode details: ");
pin=sc.nextDouble();
System.out.println("Resgistered Succesfully!!! ");
book obj=new book();
obj.msg();

	}

}
}
